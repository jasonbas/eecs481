package com.example.shout;

import android.R.bool;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	public boolean last = false;
	public static int x = 0;
	public static int y = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		setupClicks();
	}

	private void setupClicks() {
		
		Button rockButton = (Button) findViewById(R.id.Rock1);
		Button paperButton = (Button) findViewById(R.id.Paper1);
		Button scissorButton = (Button) findViewById(R.id.Scissor1);
		
		rockButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
						
				rockLogic();
						
			}
		});
		
		paperButton.setOnClickListener(new View.OnClickListener() {
					
			@Override
			public void onClick(View v) {
						
				paperLogic();
						
			}
		});

		scissorButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				scissorLogic();
				
			}
		});
		
	}

	private void rockLogic(){
		 if (last){
			  y = 0;
			 last = false;
			 end();
		 }
		 else{
			  x = 0;
			 secondTurn();
		 }
		 return;
	}
	
	private void paperLogic(){
		if (last){
			  y = 1;
			 last = false;
			 end();
		 }
		 else{
			  x = 1;
			 secondTurn();
		 }
		return;
	}
	
	private void scissorLogic(){
		if (last){
			  y = 2;
			 end();
		 }
		 else{
			 x = 2;
			 secondTurn();
		 }
		return;
	}
	
	private void end(){
		
		if(x==0 && y==0){
			//t
			Toast.makeText(MainActivity.this, "TIE!", 
					Toast.LENGTH_LONG).show();
		}
		else if(x==1 && y==1){
			//t
			Toast.makeText(MainActivity.this, "TIE!", 
					Toast.LENGTH_LONG).show();
		}
		else if(x==2 && y==2){
			//t
			Toast.makeText(MainActivity.this, "TIE!", 
					Toast.LENGTH_LONG).show();
		}
		else if(x==0 && y==1){
			//2
			Toast.makeText(MainActivity.this, "PLAYER 2 WINS!", 
					Toast.LENGTH_LONG).show();
		}
		else if(x==0 && y==2){
			//1
			Toast.makeText(MainActivity.this, "PLAYER 1 WINS!", 
					Toast.LENGTH_LONG).show();
		}
		else if(x==1 && y==0){
			//1
			Toast.makeText(MainActivity.this, "PLAYER 1 WINS!", 
					Toast.LENGTH_LONG).show();
		}
		else if(x==1 && y==2){
			//2
			Toast.makeText(MainActivity.this, "PLAYER 2 WINS!", 
					Toast.LENGTH_LONG).show();
		}
		else if(x==2 && y==0){
			//2
			Toast.makeText(MainActivity.this, "PLAYER 2 WINS!", 
					Toast.LENGTH_LONG).show();
		}
		else if(x==2 && y==1){
			//1
			Toast.makeText(MainActivity.this, "PLAYER 1 WINS!", 
					Toast.LENGTH_LONG).show();
		}
		
		x = 0;
		y = 0;
	}
	
	private void secondTurn(){
		Toast.makeText(MainActivity.this, "SECOND TURN!", 
				Toast.LENGTH_LONG).show();
		last=true;
	}
	/*@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}*/
	
}



